#!/usr/bin/env python
# coding: utf-8

# # Assignment 1 - Exploratory Data Analysis

# ## Instructions

# For the First Assignment, we are going to be Performing Exploratory Data Analysis Using Python, R and Weka.
# 
# 1. There are set of questions that may be similar for python and R but may be different for Weka.
# 2. The dataset used for Python/R are same but different for Weka.
# 3. For Task involving R use a different R notebook.
# 3. Each Task is presenting a challenge.

# ## Task 1: Python (40 Points)

# Run this cell by default to load the dataset.
# 
# This tabular dataset consists of listings of all the movies and tv shows available on Netflix, along with details such as - cast, directors, ratings, release year, duration, etc.

# In[1]:


import pandas as pd

movies_data = pd.read_csv("netflix_titles.csv")

movies_data.head()


# ### Task 1A: 2 points
# Display all the details about the dataset

# In[2]:


import pandas as pd

# Display dataset details
print(movies_data.info())
print(movies_data.describe())


# ### Task 1B: 3 points
# 1. Check for null values within each column.
# 2. Fill the values for more than 100 missing columns with certain label such as No Director, Country Unavailable, etc. Drop the rows for the rest missing columns.

# In[3]:


import pandas as pd
null_counts = movies_data.isnull().sum()
print(null_counts)


# In[4]:


null_counts = movies_data.isnull().sum()
columns_to_fill = null_counts[null_counts > 100].index.tolist()
fill_labels = ['No Director', 'Cast Unavailable', 'Country Unavailable']
for column, label in zip(columns_to_fill, fill_labels):
    movies_data[column].fillna(label, inplace=True)

# Dropping the rows of the remaining columns
# df.dropna(inplace=True)


null_counts = movies_data.isnull().sum()
print(null_counts)


# In[5]:


# Dropping the rows of the remaining columns
movies_data.dropna(inplace=True)


null_counts = movies_data.isnull().sum()
print(null_counts)


# ### Task 1C: 5 points
# Display a two horizontal bar chart side by side for Top 10 countries with total number of movies and TV shows.

# In[6]:


import matplotlib.pyplot as plt

movies_data_new = movies_data[movies_data['type'] == 'Movie']
tv_shows_data_new = movies_data[movies_data['type'] == 'TV Show']

movies_counts = movies_data_new.groupby('country')['type'].value_counts().unstack()
top10_for_movies = movies_counts.sum(axis=1).nlargest(10)
top10_for_movies_count = movies_counts.loc[top10_for_movies.index]

tv_counts = tv_shows_data_new.groupby('country')['type'].value_counts().unstack()
top_10_tv = tv_counts.sum(axis=1).nlargest(10)
top_10_counts_tv = tv_counts.loc[top_10_tv.index]


# In[7]:


fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(12, 6))
top10_for_movies_count.plot(kind='barh', stacked=True, ax=axes[0], legend=False)
axes[0].set_ylabel('Country')
axes[0].set_title('Total Number of Movies by Country')
axes[0].set_xlabel('Count')


top_10_counts_tv.plot(kind='barh', stacked=True, ax=axes[1], color='green', legend=False)
axes[1].set_ylabel('Country')
axes[1].set_title('Total Number of TV Shows by Country')
axes[1].set_xlabel('Count')


plt.tight_layout()
plt.show()


# ### Task 1D: 4 points
# 
# Print the first row based on the longest duration time of a movie from each country column with its director, date_added, release_year, duration of the movie and its description. 

# In[8]:


movies_data.tail()
movies_data['duration'] = movies_data['duration'].str.split(' ').str[0].astype(int)
max_duration_index = movies_data.groupby('country')['duration'].idxmax()

result = movies_data.loc[max_duration_index, ['country','director', 'date_added', 'release_year', 'duration']]

# Print the result
print(result.to_string(index=False))


# ### Task 1E: 4 points
# Display the titleof the movie, its director, the date it was added to the platform and the date it was officially released where the official release date and the date it was added to the plafform has same year.

# In[9]:


movies_data['date_added'] = pd.to_datetime(movies_data['date_added'])
#Comparing the release year and date addded
same_ry_da_movies = movies_data[movies_data['release_year'] == movies_data['date_added'].dt.year]
# print(same_ry_da_movies)
for index, movie in same_ry_da_movies.iterrows():
        print("Title of the Movie:", movie['title'])
        print("Director of the Movie:", movie['director'])
        print("Date Added on Netflix:", movie['date_added'])
        print("Release Date of the Movie:", movie['release_year'])
        print("***********************************")


# ### Task 1F: 4 points
# Display Director, the release year and number of movies and TV Shows directed by that director within a year and sort the results from highest.

# In[10]:


movie_tvshow_data = movies_data[movies_data['type'].isin(['Movie','TV Show'])]
# print(movie_tvshow_data)
counts = movie_tvshow_data.groupby(['director','release_year']).size().reset_index(name='count').sort_values('count', ascending = False)
columns = ['director' , 'release_year', 'count']
print(counts[columns])



# ### Task 1G: 3 points
# Display the title of the movie/TV shows, the Director, the date it was added to netflix and the category it was listed in from the data which belongs to Documentary/Docuseries category.

# In[11]:


documentry_docuseries_data = movies_data[movies_data['listed_in'].isin(['Documentaries','Docuseries'])]

#printing the required output
for index, movie in documentry_docuseries_data.iterrows():
        print("Title of the Movie:", movie['title'])
        print("Director of the Movie:", movie['director'])
        print("Date Added on Netflix:", movie['date_added'])
        print("Movie category:", movie['listed_in'])
        print("***********************************")
                                         


# ### Task 1H : 4 points
# 
# Display title, the date it was added to the plaform, type of category it was listed in and its description for Family Dramas.
# 
# Hint: Use Description to look for type of Drama.

# In[14]:


# Select Family Dramas based on the description
family_drama_movies = movies_data[movies_data['description'].str.contains('Family Drama', case = False)].copy()
# printing the required output
for index, movie in family_drama_movies.iterrows():
        print("Title of the Movie:", movie['title'])
        print("Date Added on Netflix:", movie['date_added'])
        print("Movie category:", movie['listed_in'])
        print("Description of the Movie:", movie['description'])
        print("***********************************")


# ### Task 1I: 5 points
# 
# Plot the Distribution of TV shows based on their number of seasons.(horizontal bar chart)
# 1. Less than 3 seasons
# 2. 3 Seasons
# 3. 4 Seasons
# 4. 5 to less than 10 seasons.
# 5. 10 or more seasons.

# In[14]:


movies_data = pd.read_csv("netflix_titles.csv")
tv_shows_H = movies_data[movies_data['type'] == 'TV Show']

total_season_counts = tv_shows_H['duration'].value_counts()
#Removing the Season/Seasons words to filer the duration
total_season_counts.index = total_season_counts.index.str.replace("Seasons", "")
total_season_counts.index = total_season_counts.index.str.replace("Season", "")
total_season_counts.index = pd.to_numeric(total_season_counts.index,errors='coerce')

options = {
    'Less than 3 seasons': (total_season_counts.values[total_season_counts.index < 3].sum()),
    '3 seasons': (total_season_counts.values[total_season_counts.index == 3].sum()),
    '4 seasons': (total_season_counts.values[total_season_counts.index == 4].sum()),
    '5 to less than 10 seasons': (total_season_counts.values[(total_season_counts.index >= 5) & (total_season_counts.index < 10)].sum()),
    '10 or more seasons': (total_season_counts.values[total_season_counts.index >= 10].sum())
}

plt.barh(list(options.keys()), list(options.values()))
plt.xlabel('Number of TV Shows')
plt.ylabel('Number of Seasons')
plt.title('Graph on total number of TV Shows with number of seasons')
plt.show()


# ### Task 1J: 6 points
# 
# Display a side by side pie chart where it shows different rating a movie and a TV show belongs to.
# 
# Movie:
# 1. Uncut/Not rated
# 2. Restricted
# 3. Parentel guidance
# 4. General audience
# 5. Adults only
# 
# TV Show:
# 1. All Children
# 2. Older Children
# 3. Parentel Presence
# 4. General audience
# 5. Mature

# In[16]:


import matplotlib.pyplot as plt

tv_shows_J = movies_data[movies_data['type'] == 'TV Show']
tv_rating_count = tv_shows_J['rating'].value_counts()

movies_J = movies_data[movies_data['type'] == 'Movie']
movie_rating_count = movies_J['rating'].value_counts()


# In[21]:


tv_options = {
    'All Children': tv_rating_count.get('TV-Y', 0),
    'Older Children': tv_rating_count.get('TV-Y7', 0) + tv_rating_count.get('TV-Y7-FV', 0),
    'Parental Presence': tv_rating_count.get('TV-PG', 0),
    'General audience': tv_rating_count.get('TV-G', 0),
    'Mature': tv_rating_count.get('TV-MA', 0)
}

movie_options = {
    'Uncut/Not rated': movie_rating_count.get('NR', 0),
    'Restricted': movie_rating_count.get('R', 0),
    'Parental guidance': movie_rating_count.get('PG', 0) + movie_rating_count.get('PG-13', 0),
    'General audience': movie_rating_count.get('G', 0),
    'Adults only': movie_rating_count.get('NC-17', 0)
}


# In[22]:


labels_tv = list(tv_options.keys())
sizes_tv = list(tv_options.values())

labels_movies = list(movie_options.keys())
sizes_movies = list(movie_options.values())

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))
axes[0]
ax1.pie(sizes_tv, labels=labels_tv, autopct='%1.1f%%', startangle=90)
ax1.axis('equal')
ax1.set_title('TV Shows distribution based on Rating')

ax2.pie(sizes_movies, labels=labels_movies, autopct='%1.1f%%', startangle=90)
ax2.axis('equal')
ax2.set_title('Movies distribution based on Rating')

plt.tight_layout()
plt.show()


# ## Task 2: R(40 Points)
# 
# Perform all the task for R where the data and the questions are same as that for Task 1.
# 
# Use a different R notebook.

# ## Task 3: Weka (20 Points)
# 1. For this task you will be using the "Employee_retention.csv" data file.
# 2. Load the data into Weka and perform the analysis asked for each question.
# 3. Load and Display the clear screenshot for each question analysis respectively.
# 
# Note: Target variable is 'left'

# ### Task 3A: 3 points
# Display visualization for each column

# In[ ]:





# ### Task 3B: 3 points
# Display Time spend in the company by the employee vs any work accidents that took place with reaction to target variable.
# Interpret the graph.

# In[ ]:





# In[ ]:


# Comment your interpretations.


# ### Task 3C: 3 points
# 
# Display how satisfied the employee was with their job vs if there was any promotion within last 5 years with reaction to target variable. Interpret your graph.

# In[ ]:





# In[ ]:


# Comment your interpretations here


# ### Task 3D: 3 points
# 
# Display the last evaluation score of the employee vs how satisfied the employee was with the work in reaction to the target variable. Interpret your graph.

# In[ ]:





# In[ ]:


# Comment your interpretations


# ### Task 3E: 3 points
# 
# Display average monthly worked hours for the employer vs the number of projects the employee is working on in reaction to the target variable. Interpret your graph.

# In[ ]:





# In[ ]:


# Comment your interpretations


# ### Task 3F: 5 points
# 
# Display how low salary the employee worked for vs if there was a promotion within last 5 years in reaction to the target variable. Interpret your graph.

# In[ ]:





# In[ ]:





# ### Programming Assignment Details
# 
# 1. If using any resource (books, internet), please make sure that you cite it within that cell.
# 2. Do not rename the dataset_files.
# 3. Include the Images from the Weka analysis in the submission folder with each image named with the Task(eg: Task3B, Task3C, etc).

# ###  Submission details
# Fill your name and ID in the jupyter notebook for each group member in the following format:
# 
# 1. First Student Name and ID: ABC 1001XXXXXX
# 2. Second Student Name and ID: DEF 1002XXXXXX
# 3. Third Student Name and ID: GHI 1003XXXXXX
# 
# Name your submission files:
# 
# yourLastName_Last4digitsofyourID.ipynb
# 
# EG: abc_1234_def_5678_xyz3819_python.ipynb, abc_1234_def_5678_xyz3819_R.ipynb

# ### NOTE: Only one team member will submit the file.

# In[ ]:




